enum DataType {
  STRING,
  INT,
  BOOL,
  DOUBLE,
  LISTSTRING,
}
