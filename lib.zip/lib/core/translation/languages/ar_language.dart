class ARLanguage {
  static Map<String, String> get map => {
        "key_email": "البريد الالكتروني",
        "key_email_message": "ادخل البريد الالكتروني",
        "key_password": "كلمة المرور",
        "key_password_message": "ادخل كلمة مرور صحيحة",
        "key_login": 'تسجيل الدخول',
      };
}
