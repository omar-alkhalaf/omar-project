class FRLanguage {
  static Map<String, String> get map => {
        "key_email": "Email",
      };
}
