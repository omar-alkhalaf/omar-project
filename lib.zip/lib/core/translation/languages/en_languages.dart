class ENLanguage {
  static Map<String, String> get map => {
        "key_email": "Email",
        "key_email_message": "Please enter  email",
        "key_password": "Password",
        "key_password_message": "Please enter password :)",
        "key_login": "Login",
      };
}
